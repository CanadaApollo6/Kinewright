use kinewright_project::{ProjectFile, can_overwrite_save, load_document};
#[test]
fn pinned_max2_format_controls() {
    assert_eq!(kinewright_core::PROJECT_FORMAT_VERSION,2);
    let fixture=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../kinewright-agent/tests/fixtures/ja");
    let temp=std::env::temp_dir().join(format!("kinewright-ja-s1-predecessor-{}",std::process::id()));
    std::fs::create_dir(&temp).unwrap();
    let studio=temp.join("studio.kinewright");
    let bytes=std::fs::read(fixture.join("unsupported-v3-studio.kinewright")).unwrap();
    std::fs::write(&studio,&bytes).unwrap();
    let (_,version,_)=load_document(&studio).unwrap();assert_eq!(version,3);assert!(!can_overwrite_save(version));
    assert_eq!(std::fs::read(&studio).unwrap(),bytes);
    let mut raw:serde_json::Value=serde_json::from_slice(&std::fs::read(fixture.join("writer-v2-adjustment.kinewright")).unwrap()).unwrap();
    raw["format_version"]=serde_json::json!(3);
    raw["tracks"][0]["clips"][0]["future_blend"]=serde_json::json!("screen");
    let source=serde_json::to_vec(&raw).unwrap();let path=temp.join("blend.kinewright");std::fs::write(&path,&source).unwrap();
    let file:ProjectFile=serde_json::from_slice(&source).unwrap();
    let (opened,version,_)=load_document(&path).unwrap();assert_eq!(opened,file.document);assert_eq!(version,3);assert!(!can_overwrite_save(version));
    let projected=serde_json::to_value(&opened).unwrap();assert!(projected["tracks"][0]["clips"][0].get("future_blend").is_none());
    assert_eq!(std::fs::read(&path).unwrap(),source);
    std::fs::remove_dir_all(&temp).unwrap();
}
