from pathlib import Path
import subprocess,json,hashlib,os,datetime
root=Path.cwd();out=root/'target/ms2-s1a/probe-measurements';out.mkdir(parents=True,exist_ok=True)
manifest=json.loads((root/'target/ms2-s1a/probe-fixtures/manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary=root/'target/release/examples/probe_memory'
report={'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'kernel':os.uname().release,'load_before':os.getloadavg(),'cpus':os.cpu_count(),'method':'five interleaved fixture rounds; fresh app process each sample; release binaries; native leases held through Complete; sample before Close; no build concurrent with samples','qualified_limits':{'memory_max':1073741824,'rlimit_as':1610612736,'allocation':939524096},'binaries':{str(p.relative_to(root)):sha(p) for p in [binary,root/'target/release/kinewright-media-helper',root/'target/release/kinewright-media-supervisor']},'inputs':manifest,'samples':[],'errors':[]}
try:
 for round in range(5):
  for fixture in manifest['fixtures']:
   source=root/'target/ms2-s1a/probe-fixtures'/fixture['file'];assert sha(source)==fixture['sha256']
   name=f'{round}-{source.stem}';log=out/(name+'.log')
   result=subprocess.run(['nice','-n','19',str(binary),str(source)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
   log.write_text(result.stdout)
   if result.returncode:raise RuntimeError(f'{name}: exit {result.returncode}: {result.stdout}')
   sample={'round':round,'fixture':fixture['file'],'exit':result.returncode,'log':str(log.relative_to(root)),'log_sha256':sha(log)}
   for line in result.stdout.splitlines():
    if not line.startswith('MS2_PROBE_'):continue
    fields=dict(token.split('=',1) for token in line.split()[1:])
    assert fields.pop('source')==fixture['file']
    if 'process' in fields:
     process=fields.pop('process');sample[process]={k:int(v) for k,v in fields.items()}
    else:sample['cgroup']={k:int(v) for k,v in fields.items()}
   assert all(k in sample for k in ['shim','payload','cgroup'])
   assert sample['cgroup']['oom']==sample['cgroup']['oom_kill']==0
   report['samples'].append(sample)
   print(name, 'pss_total='+str(sample['shim']['pss']+sample['payload']['pss']), 'vm_peak='+str(sample['payload']['vm_peak']),flush=True)
 report['status']='complete'
except BaseException as error:
 report['status']='failed';report['errors'].append(repr(error));raise
finally:
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['load_after']=os.getloadavg()
 (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
