from pathlib import Path
import json,sys,os
scripts=Path(__file__).resolve().parent;sys.path.insert(0,str(Path(os.environ['PF1_REPO'])/'scripts/pf1'));import validate as v
root=Path(os.environ['PF1_ROOT']);plan=v.read(sys.argv[1]);verdicts=[]
v.require(__import__('re').fullmatch(r'[A-Za-z0-9_-]+',plan['id']), 'unsafe series ID')
w=scripts/('series-'+plan['id'])
for index,item in enumerate(plan['gates']):
 try:
  v.require(v.read(w/'series.json')==plan,'changed immutable series manifest');v.artifact(root,item['pins'])
  v.require(v.read(w/f'status-{index}.json')['series']==dict(item['series'],id=plan['id'],pins=item['pins']['sha256']),'cached series differs from frozen plan')
  code=v.evaluate(root/item['pins']['path'],w/f'status-{index}.json',root)
 except (ValueError,OSError,KeyError,TypeError) as error:print('invalid_evidence: '+str(error));code=2
 verdicts.append({'pins':item['pins'],'exit':code})
print(json.dumps(verdicts,indent=2));sys.exit(2 if not verdicts or any(r['exit']==2 for r in verdicts) else 101 if any(r['exit']==101 for r in verdicts) else 1 if any(r['exit']==1 for r in verdicts) else 75 if any(r['exit']==75 for r in verdicts) else 0)
