from pathlib import Path
import subprocess,os,json,time,sys,re,signal
root=Path(__file__).resolve().parents[1];work=Path(os.environ.get('PF1_WORK',root/'work'));label,lane,binary,test=sys.argv[1:5]
sys.path.insert(0, str(Path(os.environ['PF1_REPO'])/'scripts/pf1'));import validate as pins
from launch import owned_child, gpu_sample, live_record, monitor, checked, host_readback, host_check, test_check, arm_deadline, input_environment, lh_probe
arm_deadline(590)
import secrets
evidence=Path(os.environ['PF1_ROOT']);pinfile=Path(os.environ['PF1_PINS']);spec,builds,host=checked(pins.spec,pinfile,evidence)
entry=checked(lambda:spec['protocol']['order'][int(os.environ['PF1_ROW'])]);record=Path(os.environ['PF1_RECORD'])
checked(pins.require,not record.exists() and not (work/(label+'-status.json')).exists() and not (work/'logs'/(label+'.log')).exists(),'attempt already exists')
checked(pins.require,lane==spec['lane'] and pins.digest(binary)==builds[entry['arm']]['binary']['sha256'],'launch identity mismatch')
env=os.environ.copy()
for item in sys.argv[5:]:
 key,value=item.split('=',1);env[key]=value
if lane=='LH':env['PF1_HARDWARE']='1';env['R28_HARDWARE']='1'
else:env.pop('PF1_HARDWARE',None);env.pop('R28_HARDWARE',None)
fixtures=work/'fixtures';fixtures.mkdir(parents=True,exist_ok=True)
env['TMPDIR']=str(fixtures)
log=work/'logs'/(label+'.log');samples=work/'logs'/(label+'-load.jsonl');preflight=[]
env['PF1_LH_SAMPLES']=str(samples)
if lane=='LH':env['PF1_GPU_UUID']=spec['gpu']['selected']['uuid']
def read(cmd):
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=2);return {'cmd':cmd,'exit':p.returncode,'output':p.stdout}
ticks = os.sysconf('SC_CLK_TCK'); previous = {}; previous_time = time.monotonic(); owned = {os.getpid()}
parent = os.getppid()
try:
 parent_args = (Path('/proc')/str(parent)/'cmdline').read_bytes().split(b'\0')
 if any(str(Path(__file__).resolve().parent/name).encode() in parent_args for name in ['final-measure.py','d12-pairs.py','d12-export120.py']): owned.add(parent)
except OSError: pass
def cpu_snapshot():
 global previous, previous_time
 now=time.monotonic(); interval=now-previous_time;rows=[]; current={}
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   text=(proc/'stat').read_text(); tail=text[text.rindex(')')+2:].split(); pid=int(proc.name)
   used=int(tail[11])+int(tail[12]);current[pid]=(used,int(tail[19]))
   old=previous.get(pid)
   if old and old[1]==current[pid][1]:rows.append({'pid':pid,'cpu_pct':100*(used-old[0])/ticks/(now-previous_time),'comm':text[text.index('(')+1:text.rindex(')')],'owned':pid in owned,'nice':int(tail[16])})
  except (OSError,ValueError,IndexError):pass
 previous=current;previous_time=now;rows.sort(key=lambda row:row['cpu_pct'],reverse=True)
 return {'interval_seconds':interval,'top5':rows[:5],'contamination':[row for row in rows if not row['owned'] and row['cpu_pct']>20]}
def sample():
 snap={'utc':time.time(),'monitor_nice':os.getpriority(os.PRIO_PROCESS,0),'monitor_pid':os.getpid(),'monitor_parent_pid':parent,'uptime':read(['uptime']),'cpu_instant':cpu_snapshot(),'gpu':read(['nvidia-smi']+(['-i',spec['gpu']['selected']['uuid']] if lane=='LH' else [])),'clocks':read(['nvidia-smi','--query-gpu=utilization.gpu,memory.used,pstate,clocks.gr,clocks.mem','--format=csv,noheader,nounits'])}
 if lane=='LH':snap['lh']=lh_probe(read,env)
 return snap
env['PF1_GATE']=spec['gate']
env['PF1_TOKEN']=secrets.token_hex(32)
started=time.time();cleanup={};process=None;code=2;reason='';row=None
command=['timeout','--kill-after=1','570','nice','-n','10',binary,'--exact',test,'--ignored','--nocapture','--test-threads=1']
try:
 test_check(spec,test)
 env.update(input_environment(spec,evidence,int(env['PF1_ROW'])))
 actual_host=host_readback();host_check(host,actual_host)
 cpu_snapshot();time.sleep(1)
 if lane=='LH':
  for index in range(3):
   snap=sample();query=read(['nvidia-smi','-i',spec['gpu']['selected']['uuid'],'--query-gpu=index,uuid,utilization.gpu','--format=csv,noheader,nounits'])
   (work/(label+'-preflight-raw.jsonl')).open('a').write(json.dumps(dict(snap,selected_query=query))+'\n')
   preflight.append(gpu_sample(snap['gpu'],query,snap['utc'],owned))
   if index<2:time.sleep(5)
  (work/(label+'-preflight.json')).write_text(json.dumps(preflight,indent=2))
  if pins.preflight(preflight,spec['gpu']['selected']['uuid'],time.time()):
   code=75
   raise ValueError('pending_gpu_busy')
 with log.open('x') as out,samples.open('x') as load:
  load.write(json.dumps(sample())+'\n');load.flush()
  started=time.time()
  if lane=='LH':pins.preflight(preflight,spec['gpu']['selected']['uuid'],started)
  with owned_child(command,cleanup=cleanup,env=env,stdout=out,stderr=subprocess.STDOUT) as process:
   os.setpriority(os.PRIO_PROCESS,0,19)
   owned.add(process.pid)
   def tick():
    for proc in Path('/proc').iterdir():
     if not proc.name.isdigit():continue
     try:
      stat=(proc/'stat').read_text();ppid=int(stat[stat.rindex(')')+2:].split()[1])
      if ppid in owned:owned.add(int(proc.name))
     except (OSError,ValueError):pass
    (work/(label+'-owned-pids.json')).write_text(json.dumps(sorted(owned)))
    snap=sample();load.write(json.dumps(snap)+'\n');load.flush()
   next_tick=time.monotonic()
   def pause(seconds):
    global next_tick
    next_tick+=seconds
    try:process.wait(timeout=max(0,next_tick-time.monotonic()))
    except subprocess.TimeoutExpired:pass
   monitor(process,lambda:live_record(record,env['PF1_TOKEN'],started,time.time(),spec,host,evidence,env),tick,pause)
  ended=time.time()
  final_load=sample();load.write(json.dumps(final_load)+'\n')
 child_exit=process.returncode
 code=101 if child_exit==101 else 2 if child_exit else 0
 pins.require(child_exit==0,'child exited '+str(child_exit))
 collected=live_record(record,env['PF1_TOKEN'],started,ended,spec,host,evidence,env)
 pins.require(collected is not None,'missing final collector record')
 raw,gpu=collected
 pins.require('metrics' in raw and type(raw.get('valid')) is bool,'missing final measurements')
 pins.require(raw['valid'],'collector correctness/validity failed')
 build=builds[entry['arm']]
 row=dict(entry,attempt=0,supersedes='',started_s=started,ended_s=ended,validity='valid',identity=dict({k:build[k]['sha256'] for k in ['binary','production','harness']},pins=pins.digest(pinfile),host=spec['host']['sha256']),gpu=gpu,cpu=dict(utilization_pct=sum(p['cpu_pct'] for p in final_load['cpu_instant']['top5']),load_average=os.getloadavg()[0]),metrics=raw['metrics'])
 row.update(exit=0,command=command,environment={k:value for k,value in env.items() if k.startswith(('PF1_','S3B_','R28_','VK_')) or k in ['PATH','LD_LIBRARY_PATH','TMPDIR']},preflight=preflight)
except (ValueError,OSError,KeyError,TypeError,AttributeError,subprocess.SubprocessError) as error:
 row=None
 code=101 if process is not None and process.returncode==101 and cleanup.get('reaped') else 75 if code==75 else 2
 reason=str(error)
 ended=time.time()
paths=[log,samples,record,work/(label+'-owned-pids.json'),work/(label+'-preflight-raw.jsonl')]
logs=[{'path':path.relative_to(evidence).as_posix(),'sha256':pins.digest(path)} for path in paths if path.is_file()]
receipt_path=work/(label+'-receipt.json')
receipt=dict(entry,exit=code,reason=reason,cleanup=cleanup,started_s=started,ended_s=ended,command=command,token=env['PF1_TOKEN'],pins=pins.digest(pinfile),logs=logs,host=locals().get('actual_host'))
with receipt_path.open('x') as output:json.dump(receipt,output,indent=2)
receipt_ref=dict(path=receipt_path.relative_to(evidence).as_posix(),sha256=pins.digest(receipt_path))
if row is None:
 row=dict(validity='invalid_evidence',exit=code,reason=reason,receipt=receipt_ref)
else:
 row['logs']=logs+[receipt_ref]
 row['fingerprint']=pins.fingerprint(row)
with (work/(label+'-status.json')).open('x') as output:json.dump(row,output,indent=2)
print(json.dumps(row))
sys.exit(code)
