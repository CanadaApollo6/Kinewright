from pathlib import Path
import subprocess,json,sys,os,re
scripts=Path(__file__).resolve().parent;sys.path.insert(0,str(Path(os.environ['PF1_REPO'])/'scripts/pf1'));import validate as v
from series import collect
root=Path(os.environ['PF1_ROOT']);plan=v.read(sys.argv[1])
def launch(index,ordinal,entry,role,pinfile,spec,builds,item):
 label=f'{index}-{ordinal}';env=dict(os.environ,PF1_WORK=str(w),PF1_PINS=str(pinfile),PF1_ROW=str(ordinal),PF1_RECORD=str(w/(label+'-collector.json')),S3B_RUN_OFFSET=str(entry['pair']),PF1_SEED=str(entry['seed']),S3B_SIDE=role,PF1_ONLY=entry['workload'],PF1_RUNS='1')
 code=subprocess.call(['timeout','--kill-after=1','599',sys.executable,str(scripts/'lane.py'),label,spec['lane'],str(root/builds[entry['arm']]['binary']['path']),item['test']],env=env)
 path=w/(label+'-status.json')
 return code,v.read(path) if path.exists() else dict(validity='invalid_evidence',exit=code)
try:
 v.require(re.fullmatch(r'[A-Za-z0-9_-]+',plan['id']), 'unsafe series ID')
 for journal in scripts.glob('series-*/attempts-*.jsonl'):
  v.require(journal.with_name(journal.name.replace('attempts-','status-').replace('.jsonl','.json')).is_file(),'unsealed predecessor blocks collection: '+str(journal))
 w=scripts/('series-'+plan['id']);(w/'logs').mkdir(parents=True,exist_ok=True)
 code=collect(plan,root,w,launch)
except (ValueError,OSError,KeyError,TypeError) as error:print('invalid_evidence: '+str(error));code=2
sys.exit(code)
